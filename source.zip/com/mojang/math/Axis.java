/*    */ package com.mojang.math;
/*    */ 
/*    */ import org.joml.Quaternionf;
/*    */ import org.joml.Vector3f;
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface Axis
/*    */ {
/*  9 */   public static final Axis XN = angle -> (new Quaternionf()).rotationX(-angle);
/* 10 */   public static final Axis XP = angle -> (new Quaternionf()).rotationX(angle);
/* 11 */   public static final Axis YN = angle -> (new Quaternionf()).rotationY(-angle);
/* 12 */   public static final Axis YP = angle -> (new Quaternionf()).rotationY(angle);
/* 13 */   public static final Axis ZN = angle -> (new Quaternionf()).rotationZ(-angle);
/* 14 */   public static final Axis ZP = angle -> (new Quaternionf()).rotationZ(angle);
/*    */ 
/*    */   
/* 17 */   static Axis of(Vector3f vector) { return angle -> (new Quaternionf()).rotationAxis(angle, vector); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   default Quaternionf rotationDegrees(float angle) { return rotation(angle * 0.017453292F); }
/*    */   
/*    */   Quaternionf rotation(float paramFloat);
/*    */ }


/* Location:              C:\Users\Curse\Desktop\servers\test\versions\1.21.11_unobfuscated\server-1.21.11_unobfuscated.jar!\com\mojang\math\Axis.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.0.7
 */