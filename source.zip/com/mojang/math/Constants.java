package com.mojang.math;

public class Constants {
  public static final float PI = 3.1415927F;
  
  public static final float RAD_TO_DEG = 57.295776F;
  
  public static final float DEG_TO_RAD = 0.017453292F;
  
  public static final float EPSILON = 1.0E-6F;
}


/* Location:              C:\Users\Curse\Desktop\servers\test\versions\1.21.11_unobfuscated\server-1.21.11_unobfuscated.jar!\com\mojang\math\Constants.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.0.7
 */