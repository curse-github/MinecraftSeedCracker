/*     */ package com.mojang.math;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.core.Direction;
/*     */ import net.minecraft.util.Util;
/*     */ import org.joml.Matrix3f;
/*     */ import org.joml.Matrix3fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public static enum SymmetricGroup3
/*     */ {
/*  32 */   P123(0, 1, 2),
/*  33 */   P213(1, 0, 2),
/*  34 */   P132(0, 2, 1),
/*  35 */   P312(2, 0, 1),
/*  36 */   P231(1, 2, 0),
/*  37 */   P321(2, 1, 0);
/*     */   
/*     */   private final int p0;
/*     */   private final int p1;
/*     */   private final int p2;
/*     */   private final Matrix3fc transformation;
/*     */   private static final SymmetricGroup3[][] CAYLEY_TABLE;
/*     */   private static final SymmetricGroup3[] INVERSE_TABLE;
/*     */   
/*     */   SymmetricGroup3(int p0, int p1, int p2) {
/*  47 */     this.p0 = p0;
/*  48 */     this.p1 = p1;
/*  49 */     this.p2 = p2;
/*  50 */     this
/*     */ 
/*     */ 
/*     */       
/*  54 */       .transformation = (new Matrix3f()).zero().set(permute(0), 0, 1.0F).set(permute(1), 1, 1.0F).set(permute(2), 2, 1.0F);
/*     */   }
/*     */   static  {
/*  57 */     CAYLEY_TABLE = (SymmetricGroup3[][])Util.make(() -> {
/*  58 */           values = values();
/*  59 */           SymmetricGroup3[][] table = new SymmetricGroup3[values.length][values.length];
/*  60 */           for (SymmetricGroup3 first : values) {
/*  61 */             for (SymmetricGroup3 second : values) {
/*     */               
/*  63 */               int p0 = first.permute(second.p0);
/*  64 */               int p1 = first.permute(second.p1);
/*  65 */               int p2 = first.permute(second.p2);
/*     */               
/*  67 */               SymmetricGroup3 result = (SymmetricGroup3)Arrays.stream(values).filter(()).findFirst().get();
/*     */               
/*  69 */               table[first.ordinal()][second.ordinal()] = result;
/*     */             } 
/*     */           } 
/*  72 */           return table;
/*     */         });
/*     */     
/*  75 */     INVERSE_TABLE = (SymmetricGroup3[])Util.make(() -> {
/*  76 */           values = values();
/*  77 */           return (SymmetricGroup3[])Arrays.stream(values)
/*  78 */             .map(())
/*  79 */             .toArray(());
/*     */         });
/*     */   }
/*     */   
/*  83 */   public SymmetricGroup3 compose(SymmetricGroup3 that) { return CAYLEY_TABLE[ordinal()][that.ordinal()]; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public SymmetricGroup3 inverse() { return INVERSE_TABLE[ordinal()]; }
/*     */ 
/*     */   
/*     */   public int permute(int i) {
/*  91 */     switch (i) { case 0: 
/*     */       case 1:
/*     */       
/*     */       case 2:
/*  95 */        }  throw new IllegalArgumentException("Must be 0, 1 or 2, but got " + i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public Direction.Axis permuteAxis(Direction.Axis axis) { return Direction.Axis.VALUES[permute(axis.ordinal())]; }
/*     */ 
/*     */   
/*     */   public Vector3f permuteVector(Vector3f v) {
/* 104 */     float v0 = v.get(this.p0);
/* 105 */     float v1 = v.get(this.p1);
/* 106 */     float v2 = v.get(this.p2);
/* 107 */     return v.set(v0, v1, v2);
/*     */   }
/*     */   
/*     */   public Vector3i permuteVector(Vector3i v) {
/* 111 */     int v0 = v.get(this.p0);
/* 112 */     int v1 = v.get(this.p1);
/* 113 */     int v2 = v.get(this.p2);
/* 114 */     return v.set(v0, v1, v2);
/*     */   }
/*     */ 
/*     */   
/* 118 */   public Matrix3fc transformation() { return this.transformation; }
/*     */ }


/* Location:              C:\Users\Curse\Desktop\servers\test\versions\1.21.11_unobfuscated\server-1.21.11_unobfuscated.jar!\com\mojang\math\SymmetricGroup3.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.0.7
 */