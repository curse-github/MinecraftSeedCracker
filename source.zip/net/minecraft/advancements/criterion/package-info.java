package net.minecraft.advancements.criterion;

import org.jspecify.annotations.NullMarked;



/* Location:              C:\Users\Curse\Desktop\servers\test\versions\1.21.11_unobfuscated\server-1.21.11_unobfuscated.jar!\net\minecraft\advancements\criterion\package-info.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.0.7
 */